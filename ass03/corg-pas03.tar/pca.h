/*****************************
 * By:			Ethan Corgatelli
 * File:        pca.h
 * Project:     Assignment 3
 * Class:       cs475
 * Asn. Pg:     http://marvin.cs.uidaho.edu/Teaching/CS475/pas03.pdf
 *
 *****************************/
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include "mat.h"
#include "rand.h"

