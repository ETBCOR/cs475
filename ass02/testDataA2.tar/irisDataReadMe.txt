The output file irisData#.out is the result of running
the NN with the given number of hidden nodes:

nn # < irisData.in > irisData#.out

where # is the number of hidden nodes.

