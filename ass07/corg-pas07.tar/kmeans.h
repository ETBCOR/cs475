/*****************************
 * By:			Ethan Corgatelli
 * File:        kmeans.h
 * Project:     Assignment 7
 * Class:       cs475
 * Asn. Pg:     http://marvin.cs.uidaho.edu/Teaching/CS475/pas07.pdf
 *
 *****************************/
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>

#include "mat.h"
#include "rand.h"
