/*****************************
 * By:			Ethan Corgatelli
 * File:        nn.h
 * Project:     Assignment 1 (improved!)
 * Class:       cs475
 * Asn. Pg:     http://marvin.cs.uidaho.edu/Teaching/CS475/pas01.pdf
 *
 *****************************/
#include <iostream>
#include <time.h>
#include <stdlib.h>
#include "mat.h"
#include "rand.h"

double transfer (double);
